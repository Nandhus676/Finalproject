package Phase2_EndProject_Scenario2.Phase2_EndProject_Scenario2;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
