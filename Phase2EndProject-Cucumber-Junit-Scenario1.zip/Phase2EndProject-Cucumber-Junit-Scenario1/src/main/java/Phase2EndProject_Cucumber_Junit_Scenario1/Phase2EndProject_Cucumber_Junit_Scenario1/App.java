package Phase2EndProject_Cucumber_Junit_Scenario1.Phase2EndProject_Cucumber_Junit_Scenario1;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
