package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import static steps.BaseTest.driver;

public class BuyNowPageTest {

	@Given("User launches the Star Health application with {string}")
	public void user_launches_the_star_health_application_with(String string) {
	    
	
	}

	@Then("User waits for the Welcome to Star Health pop-up and closes it")
	public void user_waits_for_the_welcome_to_star_health_pop_up_and_closes_it() {
	   
	}

	@Then("User get home page title and Validates it")
	public void user_get_home_page_title_and_validates_it() {
	    // Write code here that turns the phrase above into concrete actions

	}

	@Then("User clicks on the Buy Now button")
	public void user_clicks_on_the_buy_now_button() {
	   
	}

	@Then("User Enters data for  {string},{string},{string},{string}")
	public void user_enters_data_for(String string, String string2, String string3, String string4) {
	   
	}

	@Then("User click on getstarted button")
	public void user_click_on_getstarted_button() {
	    
	}

	@Then("User select the checkbox for myself")
	public void user_select_the_checkbox_for_myself() {
	  
	}

	@Then("user navigates to the HomePage with {string}")
	public void user_navigates_to_the_home_page_with(String string) {

	}

	
	
}