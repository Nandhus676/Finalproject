$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"c4fa9829-a1cb-48c7-b8a8-cf42bdb962bc","feature":"Test StartHealth webpage using cucumber","scenario":"Validate the Star Health Buy Now flow","start":1706780280315,"group":1,"content":"","tags":"","end":1706780281500,"className":"failed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});